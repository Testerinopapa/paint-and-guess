import { Button } from "@/components/ui/button";
import { 
  Compass, 
  Package, 
  User, 
  Save, 
  Sword, 
  Eye, 
  MessageCircle, 
  Sparkles 
} from "lucide-react";

interface ActionPanelProps {
  onAction: (action: string) => void;
  availableCommands: string[];
}

const mainActions = [
  { label: "Explore", icon: Compass, action: "explore" },
  { label: "Inventory", icon: Package, action: "inventory" },
  { label: "Stats", icon: User, action: "stats" },
  { label: "Save", icon: Save, action: "save" },
];

const commandIcons: Record<string, any> = {
  attack: Sword,
  investigate: Eye,
  talk: MessageCircle,
  cast: Sparkles,
};

export const ActionPanel = ({ onAction, availableCommands }: ActionPanelProps) => {
  return (
    <div className="flex flex-col gap-4 p-6 bg-card border-2 border-accent/30 rounded-lg glow-accent h-full">
      {/* Main Actions */}
      <div className="space-y-2">
        <h3 className="text-sm font-bold text-accent text-glow-accent uppercase tracking-wider mb-3">
          Actions
        </h3>
        <div className="grid grid-cols-2 gap-2">
          {mainActions.map(({ label, icon: Icon, action }) => (
            <Button
              key={action}
              onClick={() => onAction(action)}
              variant="secondary"
              className="h-12 flex items-center justify-center gap-2 font-fantasy text-sm hover:bg-secondary/80 hover:border-accent/50 border border-accent/20 transition-all"
            >
              <Icon className="w-4 h-4" />
              <span>{label}</span>
            </Button>
          ))}
        </div>
      </div>

      {/* Dynamic Choices */}
      <div className="flex-1 space-y-2">
        <h3 className="text-sm font-bold text-accent text-glow-accent uppercase tracking-wider mb-3">
          Available Commands
        </h3>
        <div className="space-y-2 overflow-y-auto custom-scrollbar max-h-[400px]">
          {availableCommands.map((command) => {
            const Icon = commandIcons[command.toLowerCase()] || Sparkles;
            return (
              <Button
                key={command}
                onClick={() => onAction(command)}
                variant="outline"
                className="w-full justify-start gap-3 h-10 font-terminal text-sm bg-muted/30 hover:bg-muted/50 border-accent/20 hover:border-accent/40 text-foreground hover:text-accent transition-all"
              >
                <Icon className="w-4 h-4" />
                <span>{command}</span>
              </Button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
