import { useEffect, useState } from "react";

interface Particle {
  id: number;
  x: number;
  y: number;
  size: number;
  duration: number;
  delay: number;
}

export const BackgroundEffects = () => {
  const [particles, setParticles] = useState<Particle[]>([]);

  useEffect(() => {
    // Generate random particles
    const newParticles: Particle[] = Array.from({ length: 20 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 3 + 1,
      duration: Math.random() * 10 + 8,
      delay: Math.random() * 5,
    }));
    setParticles(newParticles);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {/* Fog/mist effect */}
      <div className="absolute inset-0 bg-gradient-to-b from-secondary/10 via-transparent to-secondary/5 animate-pulse-glow" />
      
      {/* Floating particles */}
      {particles.map((particle) => (
        <div
          key={particle.id}
          className="absolute rounded-full bg-primary/20 animate-float"
          style={{
            left: `${particle.x}%`,
            top: `${particle.y}%`,
            width: `${particle.size}px`,
            height: `${particle.size}px`,
            animationDuration: `${particle.duration}s`,
            animationDelay: `${particle.delay}s`,
          }}
        />
      ))}
      
      {/* Glowing accent particles */}
      {particles.slice(0, 5).map((particle) => (
        <div
          key={`accent-${particle.id}`}
          className="absolute rounded-full bg-accent/10 animate-float-delayed blur-sm"
          style={{
            left: `${(particle.x + 50) % 100}%`,
            top: `${(particle.y + 30) % 100}%`,
            width: `${particle.size * 2}px`,
            height: `${particle.size * 2}px`,
            animationDuration: `${particle.duration + 2}s`,
            animationDelay: `${particle.delay + 1}s`,
          }}
        />
      ))}
    </div>
  );
};
