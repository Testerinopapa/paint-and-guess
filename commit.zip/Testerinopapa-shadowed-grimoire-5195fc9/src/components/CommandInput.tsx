import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send } from "lucide-react";

interface CommandInputProps {
  onSubmit: (command: string) => void;
}

export const CommandInput = ({ onSubmit }: CommandInputProps) => {
  const [command, setCommand] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (command.trim()) {
      onSubmit(command);
      setCommand("");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full">
      <div className="flex gap-2 p-4 bg-card border-2 border-accent/30 rounded-lg glow-accent">
        <div className="flex-1 relative">
          <Input
            value={command}
            onChange={(e) => setCommand(e.target.value)}
            placeholder="Type your command..."
            className="h-12 font-terminal bg-input border-accent/20 focus:border-accent/50 text-foreground placeholder:text-muted-foreground pr-10"
          />
          <div className="absolute right-3 top-1/2 -translate-y-1/2 w-2 h-5 bg-accent/60 animate-pulse" />
        </div>
        <Button 
          type="submit"
          className="h-12 px-6 bg-accent hover:bg-accent/80 text-accent-foreground font-fantasy"
        >
          <Send className="w-4 h-4" />
        </Button>
      </div>
    </form>
  );
};
