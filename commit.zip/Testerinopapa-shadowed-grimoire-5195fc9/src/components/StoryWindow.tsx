import { MapPin, Mountain, Trees, Castle } from "lucide-react";
import { useEffect, useRef } from "react";

interface StoryWindowProps {
  location: string;
  storyText: string[];
}

const locationIcons = {
  ruins: Mountain,
  forest: Trees,
  castle: Castle,
  default: MapPin,
};

export const StoryWindow = ({ location, storyText }: StoryWindowProps) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [storyText]);

  const LocationIcon = locationIcons.default;

  return (
    <div className="flex flex-col h-full">
      {/* Location Header */}
      <div className="flex items-center gap-3 p-4 bg-secondary/30 border-b-2 border-primary/30 rounded-t-lg">
        <LocationIcon className="w-5 h-5 text-primary text-glow-primary" />
        <h2 className="text-xl font-bold text-primary text-glow-primary uppercase tracking-wider">
          {location}
        </h2>
      </div>

      {/* Story Text Area */}
      <div 
        ref={scrollRef}
        className="flex-1 p-6 parchment-texture rounded-b-lg border-2 border-primary/30 glow-primary overflow-y-auto custom-scrollbar"
      >
        <div className="space-y-4 font-terminal text-foreground/90 leading-relaxed">
          {storyText.map((line, index) => (
            <p 
              key={index}
              className="animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {line}
            </p>
          ))}
        </div>
      </div>
    </div>
  );
};
