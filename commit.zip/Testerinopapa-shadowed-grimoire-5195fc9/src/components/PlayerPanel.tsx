import { Heart, Droplet, Star, Coins } from "lucide-react";
import characterPortrait from "@/assets/character-portrait.png";
import { Progress } from "@/components/ui/progress";

interface PlayerPanelProps {
  character: {
    name: string;
    level: number;
    hp: number;
    maxHp: number;
    mana: number;
    maxMana: number;
    xp: number;
    xpToNextLevel: number;
    gold: number;
  };
}

export const PlayerPanel = ({ character }: PlayerPanelProps) => {
  const hpPercent = (character.hp / character.maxHp) * 100;
  const manaPercent = (character.mana / character.maxMana) * 100;
  const xpPercent = (character.xp / character.xpToNextLevel) * 100;

  return (
    <div className="flex flex-col gap-4 p-6 bg-card border-2 border-primary/30 rounded-lg glow-primary">
      {/* Character Portrait */}
      <div className="relative">
        <div className="w-full aspect-square rounded-lg overflow-hidden border-2 border-primary/50 glow-primary">
          <img 
            src={characterPortrait} 
            alt="Character Portrait" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute -top-2 -right-2 bg-primary text-primary-foreground rounded-full w-12 h-12 flex items-center justify-center font-bold text-lg border-2 border-background">
          {character.level}
        </div>
      </div>

      {/* Character Name */}
      <h2 className="text-2xl font-bold text-primary text-center text-glow-primary">
        {character.name}
      </h2>

      {/* Stats */}
      <div className="space-y-3">
        {/* HP */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <Heart className="w-4 h-4 text-hp" />
              <span className="text-foreground/80">HP</span>
            </div>
            <span className="font-terminal text-hp">
              {character.hp}/{character.maxHp}
            </span>
          </div>
          <Progress value={hpPercent} className="h-2 bg-muted">
            <div 
              className="h-full bg-hp transition-all rounded-full"
              style={{ width: `${hpPercent}%` }}
            />
          </Progress>
        </div>

        {/* Mana */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <Droplet className="w-4 h-4 text-mana" />
              <span className="text-foreground/80">Mana</span>
            </div>
            <span className="font-terminal text-mana">
              {character.mana}/{character.maxMana}
            </span>
          </div>
          <Progress value={manaPercent} className="h-2 bg-muted">
            <div 
              className="h-full bg-mana transition-all rounded-full"
              style={{ width: `${manaPercent}%` }}
            />
          </Progress>
        </div>

        {/* XP */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <Star className="w-4 h-4 text-xp" />
              <span className="text-foreground/80">XP</span>
            </div>
            <span className="font-terminal text-xp">
              {character.xp}/{character.xpToNextLevel}
            </span>
          </div>
          <Progress value={xpPercent} className="h-2 bg-muted">
            <div 
              className="h-full bg-xp transition-all rounded-full"
              style={{ width: `${xpPercent}%` }}
            />
          </Progress>
        </div>

        {/* Gold */}
        <div className="flex items-center justify-between p-3 bg-muted rounded-md border border-primary/20">
          <div className="flex items-center gap-2">
            <Coins className="w-5 h-5 text-primary" />
            <span className="text-foreground/80">Gold</span>
          </div>
          <span className="font-terminal font-bold text-primary text-lg">
            {character.gold}
          </span>
        </div>
      </div>
    </div>
  );
};
